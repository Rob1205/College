// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
    const std::string account_number = "CharlieBrown42";
    char user_input[20]; // User input buffer

    while (true)
    {
        std::cout << "Buffer Overflow Example" << std::endl;
        std::cout << "Enter a value (max 19 characters): ";

        // Use std::cin.get to limit input length and prevent overflow
        std::cin.get(user_input, 20);

        // Check if the input was too long and if the buffer was filled completely
        if (std::cin.gcount() == 19 && std::cin.peek() != '\n') {
            std::cerr << "Input too long. Buffer overflow prevented." << std::endl;
            // Clear the error state and ignore the rest of the input
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        }

        std::cout << "You entered: " << user_input << std::endl;
        std::cout << "Account Number = " << account_number << std::endl;

        std::cout << "Press 'q' to quit or any other key to enter another value: ";
        char choice;
        std::cin >> choice;
        if (choice == 'q' || choice == 'Q') {
            break;
        }

        // Clear the console for the next input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clear the newline left in the input buffer
        std::cout << std::endl;
    }

    // Wait for user input before closing the console window
    std::cout << "Press any key to exit...";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Clear the newline left in the input buffer
    std::cin.get();
}
