#pragma warning(push)
#pragma warning(disable : 26495)
#pragma warning(disable : 6031)

#include "pch.h"  // If using precompiled headers, ensure this is included
//#include "gtest/gtest.h"  // Uncomment if not using precompiled headers
#include <vector>
#include <stdexcept>
#include <memory>

// Global test environment setup and teardown
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}

    void SetUp() override {
        srand(time(nullptr));
    }

    void TearDown() override {}
};

// Test class with shared data between tests
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override {
        collection->clear();
        collection.reset(nullptr);
    }

    void add_entries(int count) {
        assert(count > 0);
        for (auto i = 0; i < count; ++i) {
            collection->push_back(rand() % 100);
        }
    }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, CanAddToEmptyVector) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterOrEqualToSize) {
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int size : sizes) {
        collection->clear();
        add_entries(size);
        ASSERT_GE(collection->max_size(), collection->size());
    }
}

TEST_F(CollectionTest, CapacityGreaterOrEqualToSize) {
    std::vector<int> sizes = { 0, 1, 5, 10 };
    for (int size : sizes) {
        collection->clear();
        add_entries(size);
        ASSERT_GE(collection->capacity(), collection->size());
    }
}

TEST_F(CollectionTest, ResizeIncreasesCollection) {
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

TEST_F(CollectionTest, ResizeDecreasesCollection) {
    add_entries(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, ResizeDecreasesCollectionToZero) {
    add_entries(10);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(10);
    collection->clear();
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, EraseRangeErasesCollection) {
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
    add_entries(5);
    size_t old_capacity = collection->capacity();
    collection->reserve(100);
    ASSERT_GT(collection->capacity(), old_capacity);
    ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, OutOfRangeThrowsException) {
    // Purposefully calling .at() with an invalid index to test exception throwing
    ASSERT_THROW(collection->at(1), std::out_of_range);
}

TEST_F(CollectionTest, CustomPositiveTest) {
    add_entries(5);
    EXPECT_EQ(collection->size(), 5);
    collection->pop_back();
    EXPECT_EQ(collection->size(), 4);
}

TEST_F(CollectionTest, CustomNegativeTest) {
    // Purposefully calling .at() with an invalid index to test exception throwing
    ASSERT_THROW(collection->at(100), std::out_of_range);
}

#pragma warning(pop)
